% Aditi Bhaskar (aditi.bhaskar@umbc.edu)
% 23 June 2009
% Modified from the code pfb_read.m by Jehan Rehani

% This routine reads from binary pfb files the mask, pressure, saturation
% and scans down with the mask to find the landsurface indices.
% It uses this to output pressls and saturls which are pressure and
% saturation at the land surface.
%
% For modification to run, change the names of the mask, satur and pressure
% file names (first 3 lines of the code).  Running will produce two plots.

[mask,message] = fopen('deadrun.out.mask.pfb.00000','r','ieee-be');
[satur,message] = fopen('deadrun.out.satur.00035.pfb.00000','r','ieee-be');
[press,message] = fopen('deadrun.out.press.00035.pfb.00000','r','ieee-be'); 

x1 = fread(mask,1,'double');    %Lower X
y1 = fread(mask,1,'double');    %Lower Y
z1 = fread(mask,1,'double');    %Lower Z

nx = fread(mask,1,'int32');  % NX
ny = fread(mask,1,'int32');  % NY
nz = fread(mask,1,'int32');  % NZ

dx = fread(mask,1,'double');
dy = fread(mask,1,'double');
dz = fread(mask,1,'double');

ns = fread(mask,1,'int32');   % num_subgrids
for is = 1:ns;  %number of subgrids
    
    ix = fread(mask,1,'int32');
    iy = fread(mask,1,'int32');
    iz = fread(mask,1,'int32');
    
    nnx = fread(mask,1,'int32');  % nx
    nny = fread(mask,1,'int32');  % ny
    nnz = fread(mask,1,'int32');  % nz
    
    rx = fread(mask,1,'int32');
    ry = fread(mask,1,'int32');
    rz = fread(mask,1,'int32');
    
    for k=(iz+1):(iz+nnz);
        for j=(iy+1):(iy+nny);
            for i=(ix+1):(ix+nnx);
                maskout(i,j,k) = fread(mask,1,'double');
            end   % i
        end   %j
    end   %k
    
end %is

clear x1 y1 z1 nx ny nz dx dy dz ns is ix iy iz nnx nny nnz rx ry rz mask

% THEN SCAN DOWN THE MASK

landsurf=ones(i,j);
for x=1:i
    for y=1:j
        z=k;
        while (z ~= 0 && maskout(x,y,z) == 0)
            z=z-1;
        end
        landsurf(x,y)=z;
    end
end

% READ THE SATURATION AND PRESSURE PFB FILES

% SATURATION
x1 = fread(satur,1,'double');    %Lower X
y1= fread(satur,1,'double');    %Lower Y
z1 = fread(satur,1,'double');    %Lower Z

nx = fread(satur,1,'int32');  % NX
ny = fread(satur,1,'int32');  % NY
nz = fread(satur,1,'int32');  % NZ

dx = fread(satur,1,'double');
dy = fread(satur,1,'double');
dz = fread(satur,1,'double');

ns = fread(satur,1,'int32');   % num_subgrids

for is = 1:ns;  %number of subgrids
    ix = fread(satur,1,'int32');
    iy = fread(satur,1,'int32');
    iz = fread(satur,1,'int32');
    
    nnx = fread(satur,1,'int32');  % nx
    nny = fread(satur,1,'int32');  % ny
    nnz = fread(satur,1,'int32');  % nz
    
    rx = fread(satur,1,'int32');
    ry = fread(satur,1,'int32');
    rz = fread(satur,1,'int32');
    
    saturout=zeros(i,j,k);
    
    for k=(iz+1):(iz+nnz);
        for j=(iy+1):(iy+nny);
            for i=(ix+1):(ix+nnx);
                saturout(i,j,k) = fread(satur,1,'double');
            end   % i
        end   %j
    end   %k
    
end %is

% PRESS

x1 = fread(press,1,'double');    %Lower X
y1= fread(press,1,'double');    %Lower Y
z1 = fread(press,1,'double');    %Lower Z

nx = fread(press,1,'int32');  % NX
ny = fread(press,1,'int32');  % NY
nz = fread(press,1,'int32');  % NZ

dx = fread(press,1,'double');
dy = fread(press,1,'double');
dz = fread(press,1,'double');

ns = fread(press,1,'int32');   % num_subgrids

for is = 1:ns;  %number of subgrids
    
    ix = fread(press,1,'int32');
    iy = fread(press,1,'int32');
    iz = fread(press,1,'int32');
    
    nnx = fread(press,1,'int32');  % nx
    nny = fread(press,1,'int32');  % ny
    nnz = fread(press,1,'int32');  % nz
    
    rx = fread(press,1,'int32');
    ry = fread(press,1,'int32');
    rz = fread(press,1,'int32');
    
    pressout=zeros(i,j,k);
    
    for k=(iz+1):(iz+nnz);
        for j=(iy+1):(iy+nny);
            for i=(ix+1):(ix+nnx);
                pressout(i,j,k) = fread(press,1,'double');
            end   % i
        end   %j
    end   %k
    
end %is

% MAKE PRESSLS AND SATURLS WHICH ARE THE PRESSURE AND SATURATION AT THE LAND SURFACE

pressls=zeros(nx,ny);
saturls=zeros(nx,ny);

for x=1:i
    for y=1:j
        if landsurf(x,y) ~= 0
            pressls(x,y)=pressout(x,y,landsurf(x,y));
            saturls(x,y)=saturout(x,y,landsurf(x,y));
        end
    end
end

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4)/2 scrsz(3)/2.1 scrsz(4)/2])
subplot(1,2,1); imagesc(saturls)
title('Saturation (-) at the Land Surface')
colorbar
subplot(1,2,2); imagesc(pressls)
title('Pressure Head (m) at the Land Surface')
colorbar