% aditi bhaskar (aditi.bhaskar@umbc.edu)
% last modified 7 october 2010

% if the following lines are run at the bottom of your tcl file, the land
% surface pressure and saturation are extracted by pftools and written into
% text files.  (you have to modify the 3rd and 6th lines for the file names
% you want to plot).

% set mask [pfload deadrun.out.mask.pfb]
% set top [Parflow::pfcomputetop $mask]
% set data [pfload deadrun.out.press.00021.pfb]
% set top_data [Parflow::pfextracttop $top $data]
% pfsave $top_data -sa "top.pressure.txt"
% set data [pfload deadrun.out.satur.00021.pfb]
% set top_data [Parflow::pfextracttop $top $data]
%
% pfsave $top_data -sa "top.satur.txt"
%
%     set tmpname tmp
%    set filename top.pressure.txt
%     set source [open $filename]
%     set destination [open $tmpname w]
%     set content [read $source]
%     close $source
%
%     set lines [split $content \n]
%     set lines_after_deletion \
%        [lreplace $lines 0 0]
%
%     puts -nonewline $destination [join $lines_after_deletion \n]
%     close $destination
%     file rename -force $tmpname $filename
%
%     set tmpname tmp
%    set filename top.satur.txt
%     set source [open $filename]
%     set destination [open $tmpname w]
%     set content [read $source]
%     close $source
%
%     set lines [split $content \n]
%     set lines_after_deletion \
%        [lreplace $lines 0 0]
%
%     puts -nonewline $destination [join $lines_after_deletion \n]
%     close $destination
%     file rename -force $tmpname $filename

load top.press.txt
load top.satur.txt
k=1;
for j=1:80  % ny
    for i=1:90  % nx
        pressls(i,j) = top_press(k);
        saturls(i,j) = top_satur(k);
        k=k+1;
    end
end
scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4)/2 scrsz(3)/2.1 scrsz(4)/2])
subplot(1,2,1); imagesc(saturls)
title('Saturation (-) at the Land Surface')
colorbar
subplot(1,2,2); imagesc(pressls)
title('Pressure Head (m) at the Land Surface')
colorbar
