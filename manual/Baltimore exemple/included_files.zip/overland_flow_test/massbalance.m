% Aditi Bhaskar, 23 June 2009, aditi.bhaskar@umbc.edu

% This routine reads from binary pfb files the pressure & saturation.
% It uses this to output pressls and saturls which are pressure and
% saturation at the land surface.
% Then mass balance calculations are made of storage, recharge and outflow,
% and a plot of the water balance is made.

% ---- INPUT SECTION -----

load xslopeenf.txt
load yslopeenf.txt

porosity=0.001;
n=5.52e-6; % manning's n in hr/m^(1/3)
specific_storage=1e-6;

i=90;
j=80;
k=10;
dx=100;
dy=100;
dz=1;
dt=.1;
nt=20;
rain=0.005;
rainlength=10;

storage_subsurf_array=zeros(1,nt+1);
storage_surf_array=zeros(1,nt+1);
storage_array=zeros(1,nt+1);
qouttotal_array=zeros(1,nt+1);

landsurf=ones(i,j)*k; % this is for an overland flow test, where a box domain is used (so the mask is not read)

% ---- END INPUT SECTION -----

for time=0:nt
    
    clear pressls pressout qout recharge saturls saturout
    
    tstepstr=num2str(time+1);
    if time+1 < 10
        filename1=['deadrun.out.satur.0000',tstepstr,'.pfb'];
        filename2=['deadrun.out.press.0000',tstepstr,'.pfb'];
    elseif time+1 < 100
        filename1=['deadrun.out.satur.000',tstepstr,'.pfb'];
        filename2=['deadrun.out.press.000',tstepstr,'.pfb'];
    elseif time < 1000
        filename1=['deadrun.out.satur.00',tstepstr,'.pfb'];
        filename2=['deadrun.out.press.00',tstepstr,'.pfb'];
    else
        filename1=['deadrun.out.satur.0',tstepstr,'.pfb'];
        filename2=['deadrun.out.press.0',tstepstr,'.pfb'];
    end
    
    % READ THE SATURATION AND PRESSURE PFB FILES
    
    % open file
    [satur,message] = fopen(filename1,'r','ieee-be'); % (filename,permission,format)
    [press,message] = fopen(filename2,'r','ieee-be'); % (filename,permission,format)
    
    % SATURATION
    x1 = fread(satur,1,'double');    %Lower X
    y1= fread(satur,1,'double');    %Lower Y
    z1 = fread(satur,1,'double');    %Lower Z
    
    nx = fread(satur,1,'int32');  % NX
    ny = fread(satur,1,'int32');  % NY
    nz = fread(satur,1,'int32');  % NZ
    
    dx = fread(satur,1,'double');
    dy = fread(satur,1,'double');
    dz = fread(satur,1,'double');
    
    ns = fread(satur,1,'int32');   % num_subgrids
    
    for is = 1:ns;  %number of subgrids
        ix = fread(satur,1,'int32');
        iy = fread(satur,1,'int32');
        iz = fread(satur,1,'int32');
        
        nnx = fread(satur,1,'int32');  % nx
        nny = fread(satur,1,'int32');  % ny
        nnz = fread(satur,1,'int32');  % nz
        
        rx = fread(satur,1,'int32');
        ry = fread(satur,1,'int32');
        rz = fread(satur,1,'int32');
        
        saturout=zeros(i,j,k);
        
        for k=(iz+1):(iz+nnz);
            for j=(iy+1):(iy+nny);
                for i=(ix+1):(ix+nnx);
                    saturout(i,j,k) = fread(satur,1,'double');
                end   % i
            end   %j
        end   %k
        
    end %is
    
    % PRESSURE
    
    x1 = fread(press,1,'double');    %Lower X
    y1= fread(press,1,'double');    %Lower Y
    z1 = fread(press,1,'double');    %Lower Z
    
    nx = fread(press,1,'int32');  % NX
    ny = fread(press,1,'int32');  % NY
    nz = fread(press,1,'int32');  % NZ
    
    dx = fread(press,1,'double');
    dy = fread(press,1,'double');
    dz = fread(press,1,'double');
    
    ns = fread(press,1,'int32');   % num_subgrids
    
    for is = 1:ns;  %number of subgrids
        
        ix = fread(press,1,'int32');
        iy = fread(press,1,'int32');
        iz = fread(press,1,'int32');
        
        nnx = fread(press,1,'int32');  % nx
        nny = fread(press,1,'int32');  % ny
        nnz = fread(press,1,'int32');  % nz
        
        rx = fread(press,1,'int32');
        ry = fread(press,1,'int32');
        rz = fread(press,1,'int32');
        
        pressout=zeros(i,j,k);
        
        for k=(iz+1):(iz+nnz);
            for j=(iy+1):(iy+nny);
                for i=(ix+1):(ix+nnx);
                    pressout(i,j,k) = fread(press,1,'double');
                end   % i
            end   %j
        end   %k
        
    end %is
    
    % MAKE PRESSLS AND SATURLS WHICH ARE THE PRESSURE AND SATURATION AT THE LAND SURFACE
    
    for x=1:i
        for y=1:j
            pressls(x,y)=pressout(x,y,landsurf(x,y));
            saturls(x,y)=saturout(x,y,landsurf(x,y));
        end
    end
    
    % MASS BALANCE
    
    % calculate an approximate storage value. add up pressls and
    % saturation*porosity for active cells (when mask =1).
    
    storage_surf=0;
    
    for x=1:i
        for y=1:j
            if pressls(x,y) > 0
                storage_surf=storage_surf+pressls(x,y)*dx*dy;
            end
        end
    end
    
    storage_subsurf=0;
    for x=1:i
        for y=1:j
            for z=1:k
                storage_subsurf=storage_subsurf+saturout(x,y,z)*porosity*dx*dy*dz;
                if pressout(x,y,z) > 0
                    storage_subsurf=storage_subsurf+pressout(x,y,z)*specific_storage*dx*dy*dz*saturout(x,y,z)*porosity;
                end
            end
        end
    end
    
    storage=storage_surf+storage_subsurf; % in m^3
    
    storage_surf_array(1,time+1)=storage_surf;
    storage_subsurf_array(1,time+1)=storage_subsurf;
    storage_array(1,time+1)=storage;
    
    recharge=rain*i*dx*j*dy*dt;
    % m/hour * m * m = m^3/hour
    
    %    calculate outflow flows
    
    qout=zeros(i,j); % Q=VA, A=100*pressure
    
    %edges
    for y=1:j %top
        if pressls(1,y) > 0 && xslopeenf(1,y) > 0
            qout(1,y)=((xslopeenf(1,y)))^(1/2)*(pressls(1,y))^(5/3)*dx/n;
        end
    end
    
    for y=1:j %bottom
        if pressls(i,y) > 0 && xslopeenf(i,y) < 0
            qout(i,y)=(-(xslopeenf(90,y)))^(1/2)*(pressls(90,y))^(5/3)*dx/n;
        end
    end
    
    for x=1:i %left
        if pressls(x,1) > 0 && yslopeenf(x,1) > 0
            qout(x,1)=((yslopeenf(x,1)))^(1/2)*(pressls(x,1))^(5/3)*dy/n;
        end
    end
    
    for x=1:i %right
        if pressls(x,j) > 0 && yslopeenf(x,j) < 0
            qout(x,j)=(-(yslopeenf(x,j)))^(1/2)*(pressls(x,j))^(5/3)*dy/n;
        end
    end
    
    qouttotal=sum(sum(qout));  % total volumetric outflow from all edge cells
    % in m^3/hour
    
    qouttotal_array(1,time+1)=qouttotal;
    
end

recharge_array=zeros(1,nt+1);
recharge_array(1,1:rainlength)=rain*i*dx*j*dy*dt;
times=0:dt:(nt*dt);

change_storage=zeros(1,nt+1);
for time=2:nt+1
    change_storage(1,time)=storage_array(1,time)-storage_array(1,time-1);
end

change_storage_surf=zeros(1,nt+1);
for time=2:nt+1
    change_storage_surf(1,time)=storage_surf_array(1,time)-storage_surf_array(1,time-1);
end

change_storage_subsurf=zeros(1,nt+1);
for time=2:nt+1
    change_storage_subsurf(1,time)=storage_subsurf_array(1,time)-storage_subsurf_array(1,time-1);
end

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4)/2 scrsz(3)/3 scrsz(4)/2])
inv=1/dt;
plot(times,recharge_array*inv,times,qouttotal_array,times,change_storage*inv,times,change_storage_surf*inv,times,change_storage_subsurf*inv,times,change_storage*inv+qouttotal_array)
legend('recharge','surface outflow','change in storage', 'change in surface storage', 'change in subsurface storage', 'change in storage + surface outflow')
xlabel('hours')
ylabel('m^3/hour')