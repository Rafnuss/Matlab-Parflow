% aditi bhaskar (aditi.bhaskar@umbc.edu)
% last modified 7 october 2010

% for a fully saturated, steady state run, you will get only 1 pressure
% file as an out (no saturation or pressure files with timestep numbers in
% the name).  therefore, this is what you need at the bottom of the tcl to
% run this code: 
%
% set mask [pfload deadrun.out.mask.pfb]
% set top [Parflow::pfcomputetop $mask]
% 
% set data [pfload deadrun.out.press.pfb]
% set top_data [Parflow::pfextracttop $top $data]
% 
% pfsave $top_data -sa "top.press.txt"
%
% set mask [pfload deadrun.out.mask.pfb]
% set top [Parflow::pfcomputetop $mask]
% 
% set data [pfload deadrun.out.press.pfb]
% set top_data [Parflow::pfextracttop $top $data]
% 
% pfsave $top_data -sa "top.press.txt"
% 
%   set tmpname tmp
%    set filename top.press.txt
%     set source [open $filename]
%     set destination [open $tmpname w]
%     set content [read $source]
%     close $source
% 
%     set lines [split $content \n]
%     set lines_after_deletion \
%        [lreplace $lines 0 0]
% 
%     puts -nonewline $destination [join $lines_after_deletion \n]
%     close $destination
%     file rename -force $tmpname $filename

clear

load top.press.txt
k=1;
for j=1:80  % ny
for i=1:90  % nx
pressls(i,j) = top_press(k);
k=k+1;
end
end
imagesc(pressls)
colorbar

title('Pressure Head (m) at the Land Surface')
colorbar