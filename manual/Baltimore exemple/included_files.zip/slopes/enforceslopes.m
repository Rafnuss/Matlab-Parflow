% aditi bhaskar (aditi.bhaskar@umbc.edu)
% last modified 28 august 2009

% this code is for enforcing slopes along streams

% how to use this code: 
% 1) download streams for your domain from the NHD 
% 2) if necessary, use strahler stream order to select the larger rivers
%     (http://www.horizon-systems.com/nhdplus/StrahlerList.php) 
% 3) convert to a raster in arcgis using conversion tools > to raster > polyline to raster.  then convert to an ascii 
%     text file in arcgis called rivers.txt.  
% 4) now in matlab. delete the top 6 lines of text and use makestreamsfromrasterok.m to make an array of 0's and 1's
% 5) using variable editor, copy, and paste, make a separate text file (same dimensions as original array) for each stream
%     (note: this step will probably take a long time)
%    alternately, instead of step 5, you can select by attributes in arcgis and save each stream as a separate text file
% 6) modify this code: load your stream text files, modify endingarray, streamlooporder, totalnumstreams, nx and ny
% 7) optional modifications: you can change whether the enforced on a blank array or on top of the original slopes
%     also you can change what magnitude they are given (in slopemag)
% 8) run, hope it works, check it

clear

% ------ INPUT LINES -------

endingarray=[85,1; 39,1; 90,7; 90,29; 90,79; 55,80; 38,80; 80,80; 20,1; 1,40];
% x, y coordinates of exit cells of streams (cell that they leave the domain)
% in the order that they are loaded into streamlooporder below

load stream1.txt
load stream2.txt
load stream3.txt
load stream4.txt
load stream5.txt
load stream6.txt
load deadrunfixed.txt
load gwynnsfallsfixed.txt
load maidenchoicefixed.txt
load patapscofixed.txt

totalnumstreams=10;
nx=90;
ny=80;
slopemag=0.4;  % the magnitude of the enforced slopes...  
% dependent on your scale, what i did was to make this value on the order
% of the largest slope magnitude found otherwise in the domain

% load your pit filled slope text files
load xslope.txt
load yslope.txt

% to visualize the enforced slopes alone, uncomment the first two of these
% next 4 lines.  to look at the slopes you are actually going to use,
% uncomment the second two of these 4 lines

enforcedslopesx=zeros(nx,ny);   % do you want to see the slopes alone?
enforcedslopesy=zeros(nx,ny);
% enforcedslopesx=xslope;   % or add them to the other slopes
% enforcedslopesy=yslope;

outputxfilename='xslopeenf.txt';
outputyfilename='yslopeenf.txt';

% ------ END INPUT LINES -------

streamlooporder=zeros(nx,ny,totalnumstreams);

streamlooporder(:,:,1)=patapscofixed;
streamlooporder(:,:,2)=stream2;
streamlooporder(:,:,3)=stream3;
streamlooporder(:,:,4)=stream4;
streamlooporder(:,:,5)=stream5;
streamlooporder(:,:,6)=deadrunfixed;
streamlooporder(:,:,7)=gwynnsfallsfixed;
streamlooporder(:,:,8)=maidenchoicefixed;
streamlooporder(:,:,9)=stream1;
streamlooporder(:,:,10)=stream6;

for numstream=1:totalnumstreams % loop through all the streams you have
    clear order

    streaminput=streamlooporder(:,:,numstream);
    stream=streaminput;

    sized=size(stream);
    x=sized(1); %dimensions of stream
    y=sized(2);

    ending=endingarray(numstream,:);

    order(1,:)=ending;
    stream(ending(1),ending(2))=0;
    n=1;
    deadend=0;

    % search in 4 directions, save in order

    while deadend == 0  % if you haven't reached a deadend 
        i=order(n,1);
        j=order(n,2);
        foundone=0;
        if n==1; % the first time 
            if j~=y && stream(i,j+1)==1
                order(n+1,:)=[i,j+1];
                stream(order(n+1,1),order(n+1,2))=0;
            elseif j~=1 && stream(i,j-1)==1
                order(n+1,:)=[i,j-1];
                stream(order(n+1,1),order(n+1,2))=0;
            elseif i~=x && stream(i+1,j)==1
                order(n+1,:)=[i+1,j];
                stream(order(n+1,1),order(n+1,2))=0;
            elseif i~=1 && stream(i-1,j)==1
                order(n+1,:)=[i-1,j];
                stream(order(n+1,1),order(n+1,2))=0;
            else
                deadend=1;
            end
        end
        if n~=1; % the rest of the times
            if j~=y && stream(i,j+1)==1
                foundone=[foundone 1];
            end
            if j~=1 && (stream(i,j-1)==1)
                foundone=[foundone 2];
            end
            if i~=x && stream(i+1,j)==1
                foundone=[foundone 3];
            end
            if i~=1 && stream(i-1,j)==1
                foundone=[foundone 4];
            end
            if foundone == 0
                deadend=1;
%                 elev2=pcr(i,j);
            elseif foundone(2)==1
                order(n+1,:)=[i,j+1];
                stream(order(n+1,1),order(n+1,2))=0;
            elseif foundone(2)==2
                order(n+1,:)=[i,j-1];
                stream(order(n+1,1),order(n+1,2))=0;
            elseif foundone(2)==3
                order(n+1,:)=[i+1,j];
                stream(order(n+1,1),order(n+1,2))=0;
            elseif foundone(2)==4
                order(n+1,:)=[i-1,j];
                stream(order(n+1,1),order(n+1,2))=0;
            end
        end
        n=n+1;
    end

    xslope=zeros(x,y);
    yslope=zeros(x,y);
    magslopeorig=ones(x,y)*slopemag;

    for k=1:length(order) % x and y slope signs
        i=order(k,1);
        j=order(k,2);
        if k==1
            if i==1; xslope(order(k,1),order(k,2))=magslopeorig(order(k,1),order(k,2)); end
            if i==x; xslope(order(k,1),order(k,2))=-magslopeorig(order(k,1),order(k,2)); end
            if j==1; yslope(order(k,1),order(k,2))=magslopeorig(order(k,1),order(k,2)); end
            if j==y; yslope(order(k,1),order(k,2))=-magslopeorig(order(k,1),order(k,2)); end
        else
            if i==order(k-1,1)
                yslope(order(k,1),order(k,2))=(j-order(k-1,2))*magslopeorig(order(k,1),order(k,2));
            elseif j==order(k-1,2)
                xslope(order(k,1),order(k,2))=(i-order(k-1,1))*magslopeorig(order(k,1),order(k,2));
            end
        end
    end

    while max(max(stream)) == 1  % you reached the deadend, but you didn't get to all the stream cells. so now you connect them
        for m=1:x
            for n=1:y
                if stream(m,n) == 1
                    if n~=y && streaminput(m,n+1)==1 && stream(m,n+1) == 0
                        yslope(m,n)=-magslopeorig(m,n);
                        stream(m,n)=0;
                        order=[order;[m,n]];
                    elseif n~=1 && streaminput(m,n-1)==1 && stream(m,n-1) == 0
                        yslope(m,n)=magslopeorig(m,n);
                        stream(m,n)=0;
                        order=[order;[m,n]];
                    elseif m~=x && streaminput(m+1,n)==1 && stream(m+1,n) == 0
                        xslope(m,n)=-magslopeorig(m,n);
                        stream(m,n)=0;
                        order=[order;[m,n]];
                    elseif m~=1 && streaminput(m-1,n)==1 && stream(m-1,n) == 0
                        xslope(m,n)=magslopeorig(m,n);
                        stream(m,n)=0;
                        order=[order;[m,n]];
                    end
                end
            end
        end
    end

    for i=1:x % write over these slopes in enforcedslopes x and y 
        for j=1:y
            if xslope(i,j) ~= 0
                enforcedslopesx(i,j)=xslope(i,j);
                enforcedslopesy(i,j)=0;
            end
            if yslope(i,j) ~= 0
                enforcedslopesy(i,j)=yslope(i,j);
                enforcedslopesx(i,j)=0;
            end
        end
    end

end


save (outputxfilename,'enforcedslopesx','-ascii')
save (outputyfilename,'enforcedslopesy','-ascii')

quiver(-enforcedslopesy,-enforcedslopesx);
set(gca,'YDir','reverse')
xlim([0 ny]);
ylim([0 nx]);
