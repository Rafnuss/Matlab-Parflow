% aditi bhaskar (aditi.bhaskar@umbc.edu)
% last modified 7 october 2010

% this code is for use with enforceslopes.m, refer to that header for directions.

load rivers.txt
teststream=rivers;

for i=1:118 % nx
    for j=1:112 % ny
        if teststream(i,j) ~= -9999
            teststream(i,j)=1;
        end
        if teststream(i,j)==-9999
            teststream(i,j)=0;
        end
    end
end

save riversfixed.txt teststream -ascii
