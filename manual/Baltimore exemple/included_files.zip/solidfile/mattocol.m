% this takes an array to a column. read vertically along columns

load ned_gunpat500.txt

demcoltest=[];

for i=1:224  % ny
    thiscol=ned_gunpat500(:,i);
    demcoltest=[demcoltest;thiscol];
end

save demcol.txt demcoltest -ascii

